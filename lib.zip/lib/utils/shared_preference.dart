
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class SharedPreferenceHelper {
  static const String _taskKey = 'tasks';

  /// **🔥 Save Tasks to SharedPreferences**
  static Future<void> saveData(List<Map<String, dynamic>> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    String encodedData = jsonEncode(tasks);
    await prefs.setString(_taskKey, encodedData);
  }

  /// **🔥 Load Tasks from SharedPreferences**
  static Future<List<Map<String, dynamic>>> loadTasks() async {
    final prefs = await SharedPreferences.getInstance();
    String? storedData = prefs.getString(_taskKey);

    if (storedData == null) return []; // ✅ Return empty list if no data found

    List<dynamic> decodedData = jsonDecode(storedData);

    return decodedData.map((task) => Map<String, dynamic>.from(task)).toList();
  }
}

