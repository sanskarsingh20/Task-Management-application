import 'package:flutter/material.dart';
import 'package:task_manager_app/screen/Homescreen.dart';
import'package:task_manager_app/data/taskmodel.dart';
import 'package:task_manager_app/screen/addtask.dart';
import 'package:task_manager_app/management/provider.dart';
import 'package:provider/provider.dart';
import 'package:task_manager_app/utils/shared_preference.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  // Importing Task model

 {
  
}

  runApp(
    ChangeNotifierProvider(
      create: (context) => TaskProvider(),
      child: MyApp(),
  ));
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Task Manager App ',
      theme: ThemeData(primarySwatch: Colors.green

      ),
     home: ChangeNotifierProvider(
  create: (context) => TaskProvider(),
  child: HomeScreen(), // 
),

      
    );
    
     
  }
}