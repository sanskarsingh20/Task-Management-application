import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:task_manager_app/management/provider.dart';
import 'package:task_manager_app/utils/shared_preference.dart';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:task_manager_app/management/provider.dart';

class AddTask extends StatelessWidget {
  final TextEditingController _taskController = TextEditingController();
  final TextEditingController _descController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: _taskController,
            decoration: InputDecoration(labelText: 'Enter Task Title'),
          ),
          SizedBox(height: 12),
          TextField(
            controller: _descController,
            decoration: InputDecoration(labelText: 'Enter Task Description'),
          ),
          SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: () {
              String taskTitle = _taskController.text.trim();
              String taskDescription = _descController.text.trim();

              if (taskTitle.isNotEmpty && taskDescription.isNotEmpty) {
                Provider.of<TaskProvider>(context, listen: false)
                    .addTask(taskTitle, taskDescription);
                _taskController.clear();
                _descController.clear();
              }
              Navigator.pop(context);
            },
            icon: Icon(Icons.add),
            label: Text('Add Task'),
          ),
        ],
      ),
    );
  }
}
