import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:task_manager_app/data/taskmodel.dart';
import 'package:task_manager_app/utils/shared_preference.dart';

class TaskProvider with ChangeNotifier {
  List<Taskmodel> _tasks = [];

  List<Taskmodel> get tasks => _tasks;

  TaskProvider() {
    loadTasks(); // Load tasks when app starts
  }

  /// **🔥 Save Tasks to SharedPreferences**
  Future<void> saveTasks() async {
    List<Map<String,dynamic>>loadedTasks=await SharedPreferenceHelper.loadTasks();
    List<Map<String, dynamic>> taskList = _tasks.map((task) => {
      'title': task.title,
      'description': task.description,
      'isCompleted': task.isCompleted, //  Save completion status too
    }).toList();
    print ("Saving Tasks:${taskList.length}");
    loadedTasks.addAll(taskList);
    await SharedPreferenceHelper.saveData(taskList); //  Saving full task list
    notifyListeners(); // 🔥 UI Update
  }

  ///  Load Tasks from SharedPreferences**
  Future<void> loadTasks() async {
    List<Map<String, dynamic>> loadedTasks = await SharedPreferenceHelper.loadTasks();

    _tasks = loadedTasks.map((task) => Taskmodel(
      title: task['title']!,
      description: task['description']!,
      isCompleted: task['isCompleted'] ?? false, // Handle missing data
    )).toList();

    print("Tasks Loaded: ${_tasks.length}");
    notifyListeners(); //UI Update
  }

  ///  Add Task**
  void addTask(String title, String description) {
    _tasks.add(Taskmodel(title: title, description: description));
    print("Task Added:${ tasks.length}");
    saveTasks(); // ✅ Save after adding
    
    notifyListeners();
  }

  /// **🔥 Toggle Task Completion**
  void toggleTask(int index) {
    _tasks[index].isCompleted = !_tasks[index].isCompleted;
    saveTasks(); 
    notifyListeners();// ✅ Save after toggling
  }

  /// **🔥 Delete Task**
  void deleteTask(int index) {
    _tasks.removeAt(index);
    saveTasks();
    notifyListeners(); // ✅ Save after deleting
  }
}
